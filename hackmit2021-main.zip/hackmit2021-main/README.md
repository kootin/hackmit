# hackmit2021

Project for HackMIT 2021.
